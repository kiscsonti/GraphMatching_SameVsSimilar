skippable=[
    "http://xmlns.com/foaf/0.1/thumbnail",
    "http://purl.org/dc/elements/1.1/rights",
    "http://dbkwik.webdatacommons.org/ontology/thumbnail",
    "http://xmlns.com/foaf/0.1/depiction",
    "http://dbkwik.webdatacommons.org/ontology/wikiPageWikiLinkText",
    "http://dbkwik.webdatacommons.org/ontology/wikiPageWikiLink"
]
literals = [
    ["http://www.w3.org/2004/02/skos/core#prefLabel"],
    ["http://www.w3.org/2000/01/rdf-schema#label"],
    ["http://www.w3.org/2004/02/skos/core#altLabel"],
    ["http://www.w3.org/2000/01/rdf-schema#comment"],
    ["http://dbkwik.webdatacommons.org/ontology/abstract"],
    ["http://dbkwik.webdatacommons.org/ontology/wikiPageWikiLinkText"],
]

a100_exactmatch_label_path = ("/home/a100/kardosp/entity_alignment/melt_cuccok/python_cuccos/oaei_2022/results/" +
                              "exactmatch/exactmatch_label")
